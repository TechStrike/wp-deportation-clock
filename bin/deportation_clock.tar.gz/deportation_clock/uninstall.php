<?php

/**
 * @author 
 * @copyright 
 *
 * The uninstallation script.
 */

if( defined( 'ABSPATH') && defined('WP_UNINSTALL_PLUGIN') ) { 

	//delete fields
	//delete_option('deportation_clock_data');

}